<?php 
include 'connection.php';





	
	 ?>





<!DOCTYPE html>
<html>
<head>
<title></title>
 <meta charset="utf-8">
 <meta http-equiv="X-UA-Compatible" content="IE=edge">
 <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script> 

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">

<link rel="stylesheet" type="text/css" href="css/footer.css">
</head>
<body>
	<div class="footer-body">
		<div class="footer-start">
			<div class="row">

				<div class="col-lg-3">
					<p><b>Chal Dal Dot Com</b></p>
					<p>2019</p>
					
				</div>
				<div class="col-lg-3">
					<p><strong><b>Home</b></strong></p>
					<p><span><b>About US</b></span></p>
					<p><b>Projects</b></p>
					
				</div>

				<div class="col-lg-3">
					<p><strong><b>Visit</b></strong></p>
					<p>141 & 142, Love Road, Tejgaon Industrial Area, Dhaka-1208</p>
					
				</div>

				<div class="col-lg-3">
					<p><strong><b>Legal</b></strong></p>
					<p>Terms</p>
					<p>Privacy</p>
					
				</div>
				

			</div>
			<div class="row">
				<div class="col-lg-3">
					<p><B>Follow us:</B></p>
					
				</div>
				<div class="col-lg-3">
					<a href="#"><i class="fab fa-facebook-f"></i></a>
					<a href="#"><i class="fab fa-instagram"></i></a>
					<a href="#"><i class="fab fa-linkedin"></i></a>
					<a href="#"><i class="fab fa-google-plus-g"></i></a>
					
					
					
					
					
				</div>
				
			</div>

			<div class="copy_right">
				<p id="copy_right_p">&copy;2019 16.02.04.099 & 16.02.04.110,All Rights Reserved</p>
			</div>
			
		</div>
		
	</div>


                   












</body>
</html>